class Power{
    static int optimisedPower(int a,int n){ 
        if(n==0){
            return 1;
        }
        int half=optimisedPower(a,n/2);
        int halfpower=2*half;
        
        // int halfpower=optimisedPower(a,n/2)*optimisedPower(a,n/2);       Time complexity is Till : O(n);
        if(n%2!=0){
            halfpower=a*halfpower;
        }
        return halfpower;
    }
    static int power(int num,int i){
        if(i==0){
            return 1;
        }
        int result=num*power(num,i-1);
        return result;
    }
    public static void main(String args[]){
    int num=2;
    int i=5;
    System.out.println(optimisedPower(num,i));
    }
}