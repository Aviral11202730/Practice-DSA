class FactorialSum{
    //Time Complexity-O(n)
    //Space Complexity-O(n)
    public static int factorial(int n){
        if(n==0){
          return 1;
        }
        int fact=n*factorial(n-1);
        return fact;
    }
     //Time Complexity-O(n)
    //Space Complexity-O(n)
    public static int sum(int n){
        if(n==1){
            return n;
        }
        return n+sum(n-1);
    }
    public static void main(String args[]){
    int n=5;
    System.out.println(sum(n));
    }
}