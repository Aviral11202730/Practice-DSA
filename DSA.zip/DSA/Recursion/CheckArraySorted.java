class CheckArraySorted{
    public static boolean isSorted(int array[],int i){
        if(i==array.length-1){
            return true;
        }
        if(array[i]>array[i+1]){
            return false;
        }
        return isSorted(array,i+1);
    }
    public static boolean isSorted(int array[]){
  for (int i=0;i<array.length-1;i++){
    if(array[i]>array[i+1]){
        return false;
    }
  }
  return true;
    }
public static void main(String args []){
    int array[]={2,4,6,7,8};
    System.out.println(isSorted(array));
   }
}