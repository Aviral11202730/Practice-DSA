class FirstLastOccur{
    public static int firstOccur(int arr[],int i,int key){
        if(i==arr.length-1){
          return -1;
        }
        if(arr[i]==key){
           return i+1;
        }
        return firstOccur(arr,i+1,key);
    }
    public static int lastOccur(int arr[],int i,int key){
        if(i==arr.length){
            return -1;
        }
        int isFound=lastOccur(arr,i+1,key);
        if(isFound==-1 && arr[i]==key){
            return i;
        }
        return isFound;
    }
    public static void main(String args[]){
    int array []={3,2,34,2};
    System.out.println(lastOccur(array,0,3));
    }
}