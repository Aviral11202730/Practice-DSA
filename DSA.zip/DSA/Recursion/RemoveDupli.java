class RemoveDupli{

    public static void removeDuplicate(String str,StringBuilder newString,int idx, boolean map[]){
        // Base Case
        if(idx==str.length()){
            System.out.println(newString);
            return;
        }
        // Kaam
        char currChar=str.charAt(idx);
        if(map[currChar-'a']==true){
        removeDuplicate(str,newString,idx+1,map);
        }else{
            map[currChar-'a']=true;
            removeDuplicate(str,newString.append(currChar),idx+1,map);
        }

    }
    public static void main(String args[]){
   String str="aviral";
   removeDuplicate(str,new StringBuilder(""),0,new boolean[26]);
    }
}