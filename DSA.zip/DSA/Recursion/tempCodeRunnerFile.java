
    // public static void removeDuplicate(String str,int idx,StringBuilder newString,boolean map[]){
    //     // Base Case
    //     if(idx==str.length()){
    //         System.out.println(newString);
    //         return;
    //     }