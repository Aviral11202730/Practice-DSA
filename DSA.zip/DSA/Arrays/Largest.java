public class Largest{
    public static int findLargest(int num[]){
        int largest=Integer.MIN_VALUE;
        for(int i=0;i<num.length;i++){
            if(num[i]>largest){
                largest=num[i];
            }
        }
        return largest;
    }
    public static int findSmallest(int num[]){
        int smallest=Integer.MAX_VALUE;
        for(int i=0;i<num.length;i++){
            if(num[i]<smallest){
                smallest=num[i];
            }
        }
        return smallest;
    }
    public static void main(String input []){
    int arr[]={6,7,1,0,3};
    int result=findLargest(arr);
    int result1=findSmallest(arr);
    System.out.println("Largest number is "+result);
    System.out.println("Smallest number is "+result1);
    }
}