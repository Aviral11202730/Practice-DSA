class ReverseArray{
    static void printArray(int arr[]){
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }System.out.println();
     }
    public static void reverseArray(int num[]){
        int start=0;
        int end=num.length-1;
        // int temp;
        while(start<end){
           int temp=num[end];
           num[end]=num[start];
           num[start]=temp;
           start++;
           end--;
        }
       
    }
    public static void main(String args[]){
        int arr[]={6,7,1,0,3};
        reverseArray(arr);
        printArray(arr);

    }

}