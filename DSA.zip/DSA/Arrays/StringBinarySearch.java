import java.util.*;
class StringBinarySearch{
    public static int binarySearch(String arr[],String key){
        int str=0;
        int end=arr.length-1;
        while(str<=end){
            int mid=str+(end-str)/2;     //Optimize way to find mid
            int check=key.compareTo(arr[mid]);
            if(check==0){
                return mid;
            }
           else if(check>0){
               str=mid+1;
           }else{
            end=mid-1;
           }
        }
        return -1;
    }
    public static void main(String args[]){
        String arr[]={"Burger","Chai","Coffee","Dosa","Noodles"};
        String key="Chai";
        Arrays.sort(arr);
        int result=binarySearch(arr,key);
        if(result==-1){
            System.out.println("Not Found");
        }else{
            System.out.println("Found at index "+(result+1));
        }
    }
}