class ArraySearch{
    public static int linearSearch(String arr[],String key){
     for(int i=0;i<arr.length;i++){
        if(arr[i]==key){
           return i;
        }
     }
     return -1;
    }
 public static int binarySearch(int arr[],int key){
    int start=0;
    int end=arr.length-1;
    // int mid=(start+end)/2;
    while(start<=end){
        int mid=(start+end)/2;
        if(arr[mid]==key){
            return mid;
        }else if(arr[mid]<key){
            start=mid+1;
        }else{
           end=mid-1;
        }
    }
    return -1;
 }
 static void printArray(int arr[]){
    for(int i=0;i<arr.length;i++){
        System.out.print(arr[i]+" ");
    }System.out.println();
 }
    public static void main(String args[]){
        // String arr[]={"Chai","Coffee","Noodles","Dosa","Burger"};
       
        // String key="Coffee";
      int arr[]={2,4,6,7,8};
       int result=binarySearch(arr,7);
   if(result==-1){
  System.out.println("Key Not Found");
   }else{
      System.out.println("Key found at index "+(result+1));
   }
    }
}