import java.util.*;
class SubArray{
    public static void printSubArray(int arr[]){  // Time Complexity-o(n^3)
        for(int i=0;i<arr.length;i++){
            int start=i;
            for(int j=i;j<arr.length;j++){
              int end=j;
              for(int k=start;k<=end;k++){
                System.out.print(arr[k]+" ");
              }
              System.out.println();
            }
        } 
    }
    public static void sumSubArray(int arr[]){
        int sum=0;
        for(int i=0;i<arr.length;i++){
            int start=i;
            for(int j=i;j<arr.length;j++){
              int end=j;
              for(int k=start;k<=end;k++){
              sum+=arr[k];
              }
            
            }
         } System.out.println(sum);
    }
    //Max Subarray Sum:- Kadane 's Algorithm
    public static void kadane(int num[]){
      // int min=Integer.MIN_VALUE;
      int cs=0;
      int maxSum=Integer.MIN_VALUE;;
      for(int i=0;i<num.length;i++){
        cs+=num[i];
        if(cs<0){
          cs=0;
        }
        maxSum=Math.max(cs,maxSum); 
   }
System.out.println(maxSum);
    }


    public static void main(String args[]){
        int arr[]= { -2,-3, 4, -1, -2, 1, 5, -3 };
        kadane(arr);
    }
}