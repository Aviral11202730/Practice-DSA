 import java.util.*;
 class factorial{
  public  static String wordnum[]={"zero","one","two","three","four","five","six","seven","eight","nine"};
  public static int fact(int n){
    if(n==0){
     return 1;
  }
      return n*fact(n-1);
}   

  public static int sum(int n){
    if(n==1){
      return 1;
  }
      return n+sum(n-1);
}
    public static int firstOcc(int array[],int i,int key){
      if(i==array.length){
        return -1;
      }
      if(array[i]==key){
        return i;
      }
      return firstOcc(array,i+1,key);
    }
    public static boolean isSorted(int array[],int i){
      if(i==array.length-1){
        return true;
      }
    /*  if(array[i]<=array[i+1]){
        return isSorted(array,i+1);
      }
      return false;  */
      if(array[i]>array[i+1]){
        return false;
      }
      return isSorted(array,i+1);
      
}
public static int lastOccur(int arr[],int key,int i){
if(i==arr.length){
  return -1;
}
int isFound=lastOccur(arr,key,i+1);
if(isFound==-1 && arr[i]==key){
  return i;
}
return isFound;
}
// public static int power(a,n){
//   if(n==0){
//     return 1;
//   }
//   return a*power(a,n-1);
// }

public static int optimisedPower(int a,int n){
  if(n==0){
    return 1;
  }
  int halfPower=optimisedPower(a,n/2);
  int halfPowerSq=halfPower*halfPower;
  if(n%2!=0){
    halfPowerSq=a*halfPowerSq;
  }
  return halfPowerSq;
}
public static void printBinString(int n,int last,String str){
  if(n==0){
    System.out.println(str);
    return;
  }
  //kaam
 /* if(last==0){
    printBinString(n-1,0,str+"0");
    printBinString(n-1,1,str+"1");
  }else{
    printBinString(n-1,0,str+"0");
  }*/
  printBinString(n-1,0,str+"0");
  if(last==0){
    printBinString(n-1,1,str+"1");
  }
}
public static int tillingProblem(int n){
  if(n==0 || n==1){
    return 1;
  }
  return tillingProblem(n-1)+tillingProblem(n-2);
}
public static int friendsPair(int n){
  if(n==1 || n==2){
    return n;
  }
  return friendsPair(n-1)+(n-1)*friendsPair(n-2);
}

public static void removeDuplicates(String str,int idx,StringBuilder newString,boolean map[]){
  if(idx==str.length()){
    System.out.println(newString);
    return;
  }
  char currChar=str.charAt(idx);
  if(map[currChar-'a']==true){
    removeDuplicates(str,idx+1,newString,map);
  }else{
    map[currChar-'a']=true;
    removeDuplicates(str,idx+1,newString.append(currChar),map);
  }
}
public static void keyOccur(int arr[],int i,int key){
  if(i==arr.length){
    return;
  }
  if(arr[i]==key){
    System.out.print(i+" ");
  }
  keyOccur(arr,i+1,key);
}
public static void numToStr(int n){
  if(n==0){
    return;
  }
int lastdigit=n%10;
numToStr(n/10);
System.out.print(wordnum[lastdigit]+" ");


}
    public static void main(String args[]){
      //  int array[]={1,2,3,4,5};
      // System.out.println(lastOccur(array,4,2)); 
      // int a=2;
      // int n=5;
      // System.out.println(optimisedPower(a,n));
      // // printBinString(3,0,"");
      // int x=tillingProblem(3);
      // System.out.println(x);

      // removeDuplicates("aavviirraall",0,new StringBuilder(""),new boolean[26]);
      // int arr[]={3, 2, 4, 5, 6, 2, 7, 2, 2};
      // int key=2;
      // keyOccur(arr,0,key);
      numToStr(013);

      // System.out.println(0123%10);
    }
}