 public static void inorder(Node root){
        if(root==null){
            return ;
        }
        // System.out.println(root.data+" ");
        inorder(root.left);
        System.out.print(root.data+" ");
        inorder(root.right);
    }