class Patterns{
    public static void starPattern(int n){
       for(int i=0;i<n;i++){
            for(int j=0;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();   
        } 
    }
    public static void invertedStar(int n){
        for(int i=4;i>=1;i--){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void halfPyramidPattern(int n){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
            System.out.println();   
        } 
    
    }
    /* See yaa in video*/
    public static void charPattern(int n){
        char ch='A';
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                System.out.print(ch);
                ch++;
               }
            System.out.println();   
        } 
    }
public static void hollowRectangle(int col,int row){
    for(int i=1;i<=col;i++){
    for(int j=1;j<=row;j++){
        if(i==1 || j==1 || i==col || j==row){
       System.out.print("*");
    }else{
      
        System.out.print(" ");
    }
  }
System.out.println();
}
}
public static void invertedHalfPyramid(int n){
// 1 2 3 4 5 
// 1 2 3 4
// 1 2 3
// 1 2
// 1
  /*  for(int i=5;i>=1;i--){
        for(int j=1;j<=i;j++){
            System.out.print(j+" ");
        }
        System.out.println();
    }  */
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n-i+1; j++){
            System.out.print(j+" ");
        }
        System.out.println();
    }
}
public static void invertRotatedHalfPyramid(int n){
//      *
//     **
//    ***
//   ****
//  *****
for(int i=1;i<=n;i++){
   
    for(int j=1;j<=n-i;j++){
    System.out.print(" ");
  }
 
  for(int j=1;j<=i;j++){
    System.out.print("*");
  }

   System.out.println();
}
}
public static void floydTriangle(int n){
    int counter=1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i;j++){
            System.out.print(counter+" ");
            counter++;
        }
        System.out.println();
    }
}
public static void floydTriangle01(int n){
for(int i=1;i<=n;i++){
    for(int j=1;j<=i;j++){
        if((i+j)%2==0){
            System.out.print("1"+" ");
        }else{
            System.out.print("0"+" ");
        }
    }
    System.out.println();
}
}
public static void butterfly(int n){
//     *      *
// **    **
// ***  ***
// ********
// ********
// ***  ***
// **    **
// *      *
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i;j++){
            System.out.print("*");
        }
        for(int j=1;j<=2*(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=i;j++){
            System.out.print("*");
        }
        System.out.println();
    }
    for(int i=n;i>=1;i--){
        for(int j=1;j<=i;j++){
            System.out.print("*");
        }
        for(int j=1;j<=2*(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=i;j++){
            System.out.print("*");
        }
        System.out.println();
    }
}
public static void solidRombus(int n){
//     ****
//     ****
//    ****
//   ****
    for(int i=1;i<=n;i++){
        for(int j=1;j<=(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=n;j++){
            System.out.print("*");
        }
        System.out.println();
    }
}
public static void hollowRombus(int n){
//     ****
//     *  *
//    *  *
//   ****
    for(int i=1;i<=n;i++){
        for(int j=1;j<=(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=n;j++){
            if(i==1 || i==n || j==1 || j==n){
            System.out.print("*");
        }else{
            System.out.print(" ");
        }
      }
      System.out.println();
   }
}
public static void diamond(int n){
//      *   
//     ***  
//    ***** 
//   *******
//   *******
//    ***** 
//     ***  
//      *
    for(int i=1;i<=n;i++){
        for(int j=1;j<=(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=(2*i)-1;j++){
            System.out.print("*");
        }
        System.out.println();
    }

    for(int i=n;i>=1;i--){
        for(int j=1;j<=(n-i);j++){
            System.out.print(" ");
        }
        for(int j=1;j<=(2*i)-1;j++){
            System.out.print("*");
        }
        System.out.println();
    }
}

public static void main(String args[]){
int n=4;
// starPattern(4);
// invertedStar(4);
// halfPyramidPattern(4);
// charPattern(n);
// hollowRectangle(4,4);
// invertedHalfPyramid(5);
// invertRotatedHalfPyramid(5);
// floydTriangle01(n);
butterfly(4);
// solidRombus(n);
// hollowRombus(n);
// diamond(n);
       }
    }
