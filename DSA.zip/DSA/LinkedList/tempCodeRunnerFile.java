   // ll.head=ll.mergeSort(ll.head);
    // ll.zigzag();