import java.util.LinkedList;
// import java.util.*
class CollectionFrameLL{
    public static void main(String args[]){
 LinkedList<Integer> ll=new LinkedList<>();
 ll.addFirst(2);
 ll.addFirst(1);
 ll.addFirst(0);
 System.out.println(ll);
 ll.removeFirst();
 ll.removeLast();
 System.out.println(ll);
    }
}