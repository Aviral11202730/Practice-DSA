public class OOPs{
public static void main(String args[]){
    Pen p1=new Pen();
    p1.setColor("Green");
    System.out.println(p1.getColor());
    p1.setColor("Yellow");
    System.out.println(p1.getColor());
    p1.setTip(5);
    System.out.println(p1.getTip());
    BankAccount myAcc=new BankAccount();
    myAcc.username="aviralkumar";
    // myAcc.password=12345;
    myAcc.setPassword(12334);
    // System.out.print(myAcc.password);
}   
}
class Pen{
private String color;
private int tip;
 String getColor(){
    return this.color;
 }
 int getTip(){
    return this.tip;
 }
 void setColor(String newColor){
    color=newColor;
 }
void setTip(int newTip){
 tip=newTip;
 }
}
//Access Modifier
class BankAccount{
    public String username;
    private int password;
    public void setPassword(int pwd){
        password=pwd;
    }
}
class Student{
String name;
int age;
float percentage;
void setPercentage(int phy,int chem,int maths){
    percentage=(phy+chem+maths)/3;
 }
}