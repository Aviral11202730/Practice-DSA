class Inheritance{
    public static void main(String input[]){
    // Fish shark=new Fish();
    // shark.eat();
    // Dog maggi=new Dog();
    // maggi.legs=4;
    // System.out.println(maggi.legs);
    WalkingAnimal man=new WalkingAnimal();
    man.walks();
    }
}
class Animal{
    String color;
    void eat(){
        System.out.println("Animal eats");
    }
    void quality(){
        System.out.println();
    }
    void breath(){
        System.out.println("All Organisms breath's");
    }
}
class Mammals extends Animal{
void walks(){
    System.out.println("Mammals walks");
  }
}
class Dog extends Mammals{
    int legs;
}
class Fish extends Animal{
void swims(){
    System.out.println("Fish swimms");
}
}
class Birds extends Animal{
void fly(){
    System.out.print("Bird Fly in the Sky");
}
}
class WalkingAnimal extends Animal{
void walks(){
    System.out.println("Man walks on two legs");
}
}
// class Fish extends Animal{
//     int fins;
//     void swimming(){
//         System.out.println("Fish swimms");
//     }
//     void fins(int fins){
//         this.fins=fins;
//     }
// }