class Constructor{
    public static void main(String args[]){
   Student S1=new Student();
//    Student S2=new Student("Aviral",11202730);
S1.name="Aviral";
 S1.rollNo=11202730;
 S1.password="abcd";
Student S2=new Student(S1);
S2.password="xyz";
System.out.println(S2.name);
    }
}
class Student{
    String name;
    int rollNo;
    String password;
 Student(Student S1){
this.name=S1.name;
this.rollNo=S1.rollNo;
 }
    //Parameterized constructor
    Student(String name,int rollNo){
    this.name=name;
    this.rollNo=rollNo;
    }
    //Non-Parameterized constructor
    Student(){
    System.out.println("I am a construtor without parameter");
    }
}