class HybridInheritance{
    public static void main(String input[]){
    Mammal human=new Mammal();
    human.breath();
    }
}
class Animal{
void breath(){
    System.out.println("Organism Breaths");
}
}
class Fish extends Animal{
void swimming(){
    System.out.println("Swimms");
}
}
class Bird extends Animal{
   void fly(){
    System.out.println("Birds fly in the sky");
   }
}
class Mammal extends Animal{
void quality(){
    System.out.println("Lives on lands");
}
}

class Dolhpin extends Fish{

}
class Shark extends Fish{

}
class Peacock extends Bird{
    
}
class Dog extends Mammal{

}
class Human extends Mammal{

}