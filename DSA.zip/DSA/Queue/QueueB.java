//Implemetation of queue using collections
import java.util.*;
class QueueB{
    public static void main(String args[]){
    // Queue <Integer> q=new LinkedList<>();
    // Queue <String> q=new ArrayDeque<>();
    Queue<String> q=new PriorityQueue<>();
    q.add("Boy");
    q.add("Girl");
    q.add("Hello");
    // q.add(3);
    while(!q.isEmpty()){
        System.out.print(q.remove()+" ");
       
    }
    System.out.println();
    }
}