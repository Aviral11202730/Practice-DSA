import java.util.*;
public class TestCase{


    public static void main(String []args){
      System.out.print();

    }
}