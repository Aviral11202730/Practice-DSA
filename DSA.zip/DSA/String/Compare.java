class Compare{
    public static void main(String args[]){
        String fruits[]={"Apple","mango","banana"};
                  
        String largest=fruits[0];

        for(int i=1;i<fruits.length;i++){
            if(largest.compareTo(fruits[i])<0){
                largest=fruits[i];
            }
        }
  System.out.print(largest);
    }
}

/** compareToIgnoreCase ignore capital small letter */