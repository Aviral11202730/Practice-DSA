import java.util.*;
class ShortestPath{
    public static int getShortestPath(String path){
        int x=0 ,y=0;
        for(int i=0;i<path.length();i++){
            char dir=path.charAt(i);
            if(dir=='E'){
                x++;
            }else if(dir=='N'){
                y++;
            }else if(dir=='W'){
                x--;
            }else{
                y--;
            }
        }
        int X=x*x;
        int Y=y*y;
        return(int)Math.sqrt(X+Y);
    }
    public static void main(String args[]){
    String path="EW";
    System.out.print(getShortestPath(path));

    }
}