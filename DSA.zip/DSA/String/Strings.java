// import java.util.*;
public class Strings{
    public static void printLetter(String str){
        for(int i=0;i<str.length();i++){
            System.out.print(str.charAt(i));
        }
    }
    public static void main(String args[]){
    
        String str="abc";
        String str2=new String("abc");

// System.out.println(str);
// System.out.println(str2);
// Scanner sc= new Scanner(System.in);
// String name=sc.nextLine();
// System.out.print(name.length());
/* String firstName="Airal";
String lastName="Kumar";
String fullName=firstName+" "+lastName;
System.out.println(fullName);  */
// String s="Happy Holi";
// printLetter(s);
// if(str==str2){
//     System.out.print("String are equal");
// }else{
//     System.out.print("String are not equal");
// }

if(str.equals(str2)){
System.out.print("yes");
}
    }
}