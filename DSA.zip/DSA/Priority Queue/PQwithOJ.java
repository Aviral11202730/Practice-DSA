import java.util.*;
class PQwithOJ{
    static class Student implements Comparable <Student>{
        String name;
        int rank;
        public Student(String name,int rank){
            this.name=name;
            this.rank=rank;
        }
      public int compareTo(Student s2){
        return this.rank-s2.rank;
      }
    }
    public static void main(String args[]){
    /* Comparator.reverseOrder */
    //for reverse order
     PriorityQueue <Student> pq = new PriorityQueue<>();
     pq.add(new Student("Q",4));
     pq.add(new Student("E",2));
     pq.add(new Student("A",1));
     pq.add(new Student("X",5));

     while(!pq.isEmpty()){
        System.out.println(pq.peek().name +"->"+ pq.peek().rank);
        pq.remove();
     }
    }
}