/*package whatever //do not write package name here */

import java.io.*;

class Keypad {
    public static String numericKeypad(String arr[],String str){
        StringBuilder sb=new StringBuilder(" ");
        for(int i=0;i<str.length();i++){
            char ch=str.charAt(i);
            if(ch==' '){
                sb.append("0");
            }else{
                int pos=str.charAt(i)-'A';
                sb.append(arr[pos]);
            }
        }
        return sb.toString();
    }
	public static void main (String[] args) {
	    String arr[] = { "2",    "22",  "222", "3",   "33", "333",
                         "4",    "44",  "444", "5",   "55", "555",
                         "6",    "66",  "666", "7",   "77", "777",
                          "7777", "8",   "88",  "888", "9",  "99",
                          "999",  "9999" };
                          
    String str="A";
    System.out.print(numericKeypad(arr,str));
	}
}