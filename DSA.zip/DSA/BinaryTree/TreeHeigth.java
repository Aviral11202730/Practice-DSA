import java.util.*;
class TreeHeigth{
    static class Node{
     int data;
     Node left;
     Node right;
     Node(int data){
        this.data=data;
        this.left=left;
        this.right=right;
     }
    }
    
  public static int heigth(Node root){
   if(root==null){
    return 0;
   }
   int lh=heigth(root.left);
   int rh=heigth(root.right);
   return Math.max(lh,rh)+1;
    }
    public static int count(Node root){
     if(root==null){
      return 0;
     }
     int leftcount=count(root.left);
     int rightcount=count(root.right);
     return leftcount+rightcount+1;
    }
   public static int sum(Node root){
    if(root==null){
      return 0;
    }
    int leftSum=sum(root.left);
    int rightSum=sum(root.right);
    return leftSum+rightSum+root.data;
   }
  public static int diameter1(Node root){  //O(n^2)
    if(root==null){
      return 0;
    }
    int leftDia=diameter1(root.left);
    int leftHt=heigth(root.left);
    int rightDia=diameter1(root.right);
    int rightHt=heigth(root.right);
    
    int selfdia=leftHt+rightHt+1;
    return Math.max(selfdia,Math.max(leftDia,rightDia));
  }
  static class Info{
    int dia;
    int ht;
    public Info(int dia,int ht){
      this.dia=dia;
      this.ht=ht;
    }
  }
  public static Info diameter(Node root){ //O(n)
  if(root==null){
    return  new Info(0,0);
  }
  Info leftInfo=diameter(root.left);
  Info rightInfo=diameter(root.right);
  int dia=Math.max(Math.max(leftInfo.dia,rightInfo.dia),leftInfo.ht+rightInfo.ht+1);
  int ht=Math.max(leftInfo.ht,rightInfo.ht)+1;
  return new Info(dia,ht);
  }
  public static boolean isIdentical(Node node,Node SubRoot){
   if(node==null && SubRoot==null){
    return true;
   }else if(node==null || SubRoot==null || node.data!=SubRoot.data){
    return false;
   }
   if(!isIdentical(node.left,SubRoot.left)){
    return false;
   }
   if(!isIdentical(node.right,SubRoot.right)){
    return false;
   }
   return true;
  }
  public static boolean isSubtree(Node root,Node SubRoot){
    if(root==null){
      return false;
    }
    if(root.data==SubRoot.data){
      if(isIdentical(root,SubRoot)){
        return true;
      }
    }
 boolean leftAns=isSubtree(root.left,SubRoot);
 boolean rightAns=isSubtree(root.right,SubRoot);

 return leftAns || rightAns;
    }
    static class Infor{
      Node node;
      int hd;
      public Infor(Node node,int hd){
        this.node=node;
        this.hd=hd;
      }
    }
    public static void topViews(Node root){
      Queue<Infor> q=new LinkedList<>();
      HashMap<Integer,Node> map=new HashMap<>();
      int min=0,max=0;
      q.add(new Infor(root,0));
      q.add(null);
      while(!q.isEmpty()){
        Infor curr=q.remove();
        if(curr==null){
          if(q.isEmpty()){
            break;
          }else{
            q.add(null);
          }
        }else{
         if(!map.containsKey(curr.hd)){
          map.put(curr.hd,curr.node);
         }
         if(curr.node.left!=null){
          q.add(new Infor(curr.node.left,curr.hd-1));
          min=Math.min(min,curr.hd-1);
         }
         if(curr.node.right!=null){
          q.add(new Infor(curr.node.right,curr.hd+1));
          max=Math.max(max,curr.hd+1);
         }
        }
      }
      for(int i=min;i<=max;i++){
        System.out.print(map.get(i).data+" ");
      }
      System.out.println();
    }
    // static class Infor{
    //   Node node;
    //   int hd;
    //   public Infor(Node node,int hd){
    //     this.node=node;
    //     this.hd=hd;
    //   }
    //   public static void topViews(Node root){
    //     // if(root==null){
    //     //   return new Infor(0,0);
    //     // }
    //     int min=0,max=0;
    //     Queue <Infor> q=new LinkedList<>();
    //     HashMap<Integer,Node> map=new HashMap<>(); 
    //     q.add(new Infor(root,0));
    //     q.add(null);
    //     while(!q.isEmpty()){
    //       Infor curr = q.remove();
    //       if(curr==null){
    //        if(q.isEmpty()){
    //         break;
    //        }else{
    //         q.add(null);
    //        }
    //       }else{
    //         if(!map.containsKey(curr.hd)){
    //           map.put(curr.hd,curr.node);
    //         }
    //         if(curr.node.left!=null){
    //           q.add(new Infor(curr.node.left,curr.hd-1));
    //           min=Math.min(min,curr.hd-1);
    //         }
    //         if(curr.node.right!=null){
    //           q.add(new Infor(curr.node.right,curr.hd+1));
    //           max=Math.max(max,curr.hd+1);
    //         }
    //       }
    //     }
    //     for(int i=min;i<=max;i++){
    //       System.out.print(map.get(i).data+" ");
    //     }
    //   }
    // }
    public static void Klevel(Node root,int level,int k){
      if(root==null){
        return;
      }
      if(level==k){
       System.out.print(root.data+" ");
       return;
      }
      Klevel(root.left,level+1,k);
      Klevel(root.right,level+1,k);
    }
    public static boolean getPath(Node root,int n,ArrayList<Node> path){
      if(root==null){
        return false;
      }
      path.add(root);
      if(root.data==n){
        return true;
      }
      boolean foundLeft=getPath(root.left,n,path);
      boolean foundRight=getPath(root.right,n,path);
      if(foundLeft || foundRight){
        return true;
      }
      path.remove(path.size()-1);
      return false;
    }
    public static Node lca(Node root,int n1,int n2){
      ArrayList <Node> path1=new ArrayList<>();
      ArrayList<Node> path2=new ArrayList<>();
      getPath(root,n1,path1);
      getPath(root,n2,path2);
      int i=0;
      for(i=0;i<path1.size()&&i<path2.size();i++){
        if(path1.get(i)!=path2.get(i)){
          break;
        }
      }
      Node loc=path1.get(i-1);
      return loc;
    }
  
public static void main(String args[]){
        /*
              1
            /   \
           2     3
          / \   / \
         4   5 6   7

      */
  Node root= new Node(1);
  root.left=new Node(2);
  root.right=new Node(3);
  root.left.left=new Node(4);
  root.left.right=new Node(5);
  root.right.left=new Node(6);
  root.right.right=new Node(7);
  // System.out.println(heigth(root));
  // System.out.println(count(root));
  // System.out.println(sum(root));
  // System.out.println(diameter(root).ht);
 //   Node SubRoot=new Node(2);
// SubRoot.left=new Node(4);
// // SubRoot.right=new Node(5);
// System.out.println(isSubtree(root,SubRoot));
// int k=2;
// Klevel(root,1,k);
topViews(root);
// int n1=4, n2=5;
// System.out.println(lca2(root,n1,n2).data);
    }
}