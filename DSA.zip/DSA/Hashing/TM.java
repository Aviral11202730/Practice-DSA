import java.util.*;
public class TM{
  public static void main(String args[]){
    TreeMap<String,Integer> tm=new TreeMap<>();
    tm.put("India",100);
    tm.put("China",150);
    tm.put("US",10);
    tm.put("Japan",5);

    System.out.print(tm);
  }
}