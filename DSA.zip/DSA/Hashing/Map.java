import java.util.*;
class Map{
    public static void main(String args[]){
     
  HashMap<String,Integer> map=new HashMap<>();

  map.put("India",150);
  map.put("China",200);
  map.put("Nepal",50);

  System.out.println(map);

  //Get -O(1)
 
 /* int population=map.get("India");
  System.out.println(population);
  System.out.println(map.get("US")); */

  //containsKey -O(1)
  /* System.out.println(map.containsKey("India"));
   System.out.println(map.containsKey("America")); */

   //remove -O(1)
   /*System.out.println(map.remove("China"));
   System.out.println(map);
   System.out.println(map.remove("Sri Lanka")); */

//    System.out.println(map.size());

//Empty function

/*System.out.println(map.isEmpty());
map.clear();
System.out.println(map.isEmpty()); */

Set<String> key=map.keySet();
System.out.print(key);

for(String k:key){
    System.out.println("Key="+k+ ",value="+map.get(k));
}
    }
}