import java.util.*;
public class LinkedHashSets{
    public static void main(String args[]){
        LinkedHashSet <String> set= new LinkedHashSet<>();
        set.add("Delhi");
        set.add("Mumbai");
        set.add("Punjab");
        set.add("Ambala");

        System.out.println(set);
        set.remove("Punjab");
        System.out.println(set);

    }
}