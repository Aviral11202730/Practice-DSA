import java.util.*;
public class LHM{
    public static void main(String args[]){
      LinkedHashMap<String,Integer> lm=new LinkedHashMap<>();
      lm.put("India",100);
      lm.put("China",150);
      lm.put("US",10);
      lm.put("Japan",5);
  
     System.out.println(lm);

    }
}