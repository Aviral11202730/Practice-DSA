import java.util.*;
public class Tickets{

     public static String getStarted(HashMap<String,String> ticket){
     HashMap<String,String> revTic=new HashMap<>();

    for(String key: ticket.keySet()){
       revTic.put(ticket.get(key),key);
    }
 for(String key:ticket.keySet()){
    if(!revTic.containsKey(key)){
        return key;
    }
 }
 return null;
}
    public static void main(String args[]){
    HashMap<String,String> ticket=new HashMap<>();
       ticket.put("Chennai","Bengaluru");
       ticket.put("Mumbai","Delhi");
       ticket.put("Goa","Chennai");
       ticket.put("Delhi","Goa");

       String Start=getStarted(ticket);
 
      System.out.print(Start+"");

       for(String key:ticket.keySet()){
        System.out.print("-> "+ticket.get(Start));
        Start=ticket.get(Start);
       }
 System.out.println();
      }
}