import java.util.*;
class TreeSets{
    public static void main(String args[]){
        TreeSet <String> set=new TreeSet<>();
        set.add("Mumbai");
        set.add("Pune");
        set.add("Varansi");
        set.add("Kanpur");
        
        System.out.println(set);
    }
}